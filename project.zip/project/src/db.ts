
import { model, connect, Schema } from "mongoose";

export async function connection() {
    let connectionURL: string = "mongodb+srv://admin:ShLoK%40123@cluster0.cbcxu.mongodb.net/HackerHive";
    await connect(connectionURL).then(() => console.log("DB Connected")).catch((err) => console.log(err))
}
/*
user role based => name , password , gmail , role
admin => hackathon , date 
participant => teamName, Time , status , badge
teams => particpants name , hacathonParticipated , projectName
guest => HacathonTheyWillJudge , scores
project => overview , techStak , linkofPPT
hackathon => overview , tags , mode ,location , timeStamp, img
hackathon teams => teamName , scores , eligible
 */
enum RoleEnum {
    admin = "admin",
    participant = "participant",
    judge = "judge",
    user = "User"
}

enum Tags {
    WebDev = "Web Development",
    ML = "Machine Learning",
    AI = "Artifical Intelligence",
    DS = "Data Science"
}
enum mode {
    online = "Online",
    Offline = "Offline"
}



const userSchema = new Schema({
    name: { type: String, required: true },
    password: { type: String },
    email: { unique: true, required: true, type: String },
    googleId :{type : String, required : true},
    role: { type: String, enum: Object.values(RoleEnum), default: RoleEnum.user }
})



const adminSchema = new Schema({
    UserId: { type: Schema.Types.ObjectId, required: true, ref: 'users' },
    hackathonId: { type: [Schema.Types.ObjectId], ref: 'hackathons' }
})



const participantSchema = new Schema({
    UserId: { type: Schema.Types.ObjectId, ref: 'users' },
    teamName: { type: String },
    status: { type: Boolean }
})



const TeamSchema = new Schema({
    captain : {type: Schema.Types.ObjectId, ref: 'users' },
    teamName: { type: String },
    participantId: { type: [Schema.Types.ObjectId], ref: 'users' },
    hackathonParticipatedId: { type: [Schema.Types.ObjectId], ref: 'hackathons' },
})



//------------------------------------------------------------------------------------------

interface judge {
  name: string;
  expertise: string;
  bio: string;
  email: string;
  invited: boolean;
}

interface JudgeDocument extends Document {
  hackathonId: Schema.Types.ObjectId;
  userId: Schema.Types.ObjectId;
  judges: judge[];
}

const judgeSchema = new Schema<JudgeDocument>({
  hackathonId: { type: Schema.Types.ObjectId, ref: "Hackathon", required: true },
  userId: { type: Schema.Types.ObjectId, ref: "User", required: true },

  judges: [
    {
      name: { type: String, required: true },
      expertise: { type: String, required: true },
      bio: { type: String},
      email: { type: String, required: true, unique: true },
      invited: { type: Boolean, default: false },
    },
  ],
});


//-------------------------------------------------------------------------------------------------------------



const projectSchema = new Schema({
    teamId: { type: Schema.Types.ObjectId, ref: 'teams' },
    overview: { type: String, required: true },
    techstack: { type: [String], required: true },
    linkOfPPT: { type: String },
    hackathaonId: { type: Schema.Types.ObjectId, ref: 'hackathons' },
    score: { type: Number }
})


//------------------------------------------------------------------------------


enum Mode {
    VIRTUAL = "virtual",
    IN_PERSON = "in-person",
  }
  
  interface Eligibility {
    ageMin: number;
    ageMax: number;
    skillLevel: string;
    location: string;
    requirements: string;
  }
  
  interface Schedule {
    date: string;
    time: string;
    event: string;
    description: string;
  }
  
  interface Hackathon extends Document {
    title: string;
    description: string;
    startDate: Date;
    endDate: Date;
    maxParticipants: number;
    prizePool: string;
    registrationDeadline: Date;
    
    eventType: Mode;
    venue?: string;
    platform?: string;
    platformLink?: string;
  
    eligibility: Eligibility;
    
    theme: string;
    tracks: string[];
    
    rules: string[];
    
    schedule: Schedule[];
  
    sponsors: string[];
  }
  
  const hackathonSchema = new Schema<Hackathon>({
    title: { type: String, required: true, unique: true },
    description: { type: String, required: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    maxParticipants: { type: Number, required: true },
    prizePool: { type: String, required: true },
    registrationDeadline: { type: Date, required: true },
  
    eventType: { type: String, enum: Object.values(Mode), required: true },
    venue: { type: String },
    platform: { type: String },
    platformLink: { type: String },
  
    eligibility: {
      ageMin: { type: Number, required: true },
      ageMax: { type: Number, required: true },
      skillLevel: { type: String, required: true },
      location: { type: String, required: true },
      requirements: { type: String },
    },
  
    theme: { type: String, required: true },
    tracks: { type: [String], required: true },
  
    rules: { type: [String], required: true },
  
    schedule: [
      {
        date: { type: String, required: true },
        time: { type: String, required: true },
        event: { type: String, required: true },
        description: { type: String, required: true },
      },
    ],
  
    sponsors: { type: [String], required: true },
  });
//-----------------------------------------------------------------------------
const project = model('projects', projectSchema);
const hackathon = model('hackathons', hackathonSchema);
const judge = model('judges', judgeSchema);
const Team = model('teams', TeamSchema);
const Participant = model('participants', participantSchema);
const Admin = model('admins', adminSchema);
const User = model('User', userSchema);


export { User, project, hackathon, judge, Team, Participant, Admin };

