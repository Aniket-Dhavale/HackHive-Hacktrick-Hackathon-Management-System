import express, { NextFunction, Request, Response } from "express";
import { Admin, connection, hackathon, judge, Participant, project, Team , User } from "./db";
import passport from "passport";
import session from "express-session";
import dotenv from "dotenv";
import cors from "cors";
import jwt from "jsonwebtoken";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as GitHubStrategy } from "passport-github2";

dotenv.config();

const app = express();
connection();
app.use(express.json());
app.use(cors());


app.use(express.json());
app.use(cors({ origin: "http://localhost:5173", credentials: true }));

// ✅ Session Middleware
app.use(
  session({
    secret: "TehelkaOmlet",
    resave: false,
    saveUninitialized: false,
  })
);

app.use(passport.initialize());
app.use(passport.session());

// ✅ JWT Token Generator
const generateToken = (user: any) => {
  return jwt.sign({ id: user._id }, "TehelkaOmlet", { expiresIn: "1h" });
};

// ✅ Google OAuth Strategy
passport.use(
  new GoogleStrategy(
    {
      clientID: '42507196802-p10apo2t92tinuhplql86af9l1m8dlpu.apps.googleusercontent.com',
      clientSecret: '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',
      callbackURL: "http://localhost:8080/auth/google/callback",
    },
    async (accessToken, refreshToken, profile, done) => {
      let user = await User.findOne({ googleId: profile.id });
      if (!user) {
        user = await User.create({
          googleId: profile.id,
          name: profile.displayName,
          email: profile.emails?.[0].value,
        });
      }
      return done(null, user);
    }
  )
);

passport.serializeUser((user: any, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
  const user = await User.findById(id);
  done(null, user);
});

// ✅ Redirect User to Google Login
app.get("/auth/google", passport.authenticate("google", { scope: ["profile", "email"] }));

// ✅ Handle Google OAuth Callback & Return JWT
app.get(
  "/auth/google/callback",
  passport.authenticate("google", { session: false }),
  (req: any, res) => {
    const token = generateToken(req.user);
    res.redirect(`http://localhost:5173/login-success?token=${token}`); // Redirect to frontend with token
  }
);

// ✅ Logout User
app.post("/logout", (req, res) => {
  req.logout(() => {
    res.status(200).json({ message: "Logged out successfully" });
  });
});


enum Mode {
  VIRTUAL = 'virtual',
  IN_PERSON = 'in-person',
  HYBRID = 'hybrid'
}

function verify(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ message: "Access denied. No token provided." });
    return;
  }

  const token = authHeader.split(" ")[1]; // Extract token from "Bearer <token>"

  try {
    //@ts-ignore
    const decoded = jwt.verify(token, "TehelkaOmlet") as DecodedToken; // Type assertion
    (req as any).user = decoded.id; // Attach decoded token data (including id) to request
    console.log("User ID:", decoded.id); // Debugging: Log extracted user ID
    next();
  } catch (error) {
    res.status(403).json({ message: "Invalid token." });
  }
}



//-----------------------------------------------------------------------------------------
//Home Part

app.get("/home", verify, async (req: Request, res: Response): Promise<void> => {
  try {
    let user = (req as any).user;
    let person = await User.findOne({ _id: user });
    let hackathons = await hackathon.find();
    if (!person) {
      res.status(404).json({ message: "User not found" });
      return;
    }
    if (person.role === "User") {
      res.status(200).json({ hackathons });
      return;
    }
    if (person.role === "participant") {
      let participantHackathons = await Team.find({ participantId: { $in: user } })
        .populate("hackathonParticipatedId");
      res.status(200).json({ participantHackathons, hackathons });
      return;
    }
    if (person.role === "admin") {
      let organisedHackathons = await Admin.findOne({ UserId: user })
        .populate("hackathonId");
      res.status(200).json({ organisedHackathons, hackathons });
      return;
    }
    let judgeHackathon = await judge.findOne({ userId: user }).populate("hackathonId");
    res.status(200).json({ judgeHackathon, hackathons });
  } catch (error) {
    console.error("Error fetching home data:", error);
    res.status(500).json({ message: "Internal Server Error", error });
  }
});

app.get("/api/hackathons/:id", async (req, res) => {
  try {
    const hackathonData = await hackathon.findById(req.params.id).lean();
    
    if (!hackathonData) {
       res.status(404).json({ message: "Hackathon not found" });
       return
    }

 
    const response = {
      ...hackathonData,
      venue: hackathonData.venue || 'Virtual',
      //@ts-ignore
      currentParticipants: hackathonData.currentParticipants || 0,
      //@ts-ignore
      image: hackathonData.image || '/default-hackathon.jpg',
      status: new Date() < new Date(hackathonData.startDate) 
        ? 'upcoming' 
        : new Date() <= new Date(hackathonData.endDate) 
          ? 'ongoing' 
          : 'completed',
      sponsors: hackathonData.sponsors || [],
      // Convert schedule to actual data structure
      schedule: hackathonData.schedule?.map((day: any) => ({
        date: day.date,
        events: day.events?.map((event: any) => ({
          time: event.time,
          title: event.event, // Note: using 'event' field from schema as 'title'
          description: event.description
        })) || []
      })) || [],
      //@ts-ignore
      prizes: hackathonData.prizes || [],
      eligibility: {
        age: `${hackathonData.eligibility.ageMin || 18}+ years`,
        skillLevel: hackathonData.eligibility.skillLevel || 'Any',
        teamSize: '2-4 members', // Default value
        requirements: hackathonData.eligibility.requirements 
          ? [hackathonData.eligibility.requirements] 
          : []
      }
    };

    res.json(response);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Server error" });
  }
});



/*enum Mode {
  VIRTUAL = "virtual",
  IN_PERSON = "in-person",
}*/

interface JudgeSubmission {
  name: string;
  expertise: string;
  bio: string;
  email: string;
  invited: boolean;
}

interface Eligibility {
  ageMin: number;
  ageMax: number;
  skillLevel: string;
  location: string;
  requirements: string;
}

interface ScheduleItem {
  date: string;
  time: string;
  event: string;
  description: string;
}

app.post('/hackathons',verify, async (req: Request, res: Response) => {
  try {
    // Verify authentication
    let userId = (req as any).user; // Assuming you have authentication middleware
    if (!userId) {
      res.status(401).json({ 
        success: false,
        message: "Unauthorized: User not authenticated"
      });
      return 
    }

    // Destructure and validate request body
    const {
      title,
      description,
      startDate,
      endDate,
      maxParticipants,
      prizePool,
      registrationDeadline,
      eventType,
      venue,
      platform,
      platformLink,
      eligibility,
      theme,
      tracks = [],
      rules = [],
      schedule = [],
      sponsors = [],
      judges = [],
      contact
    } = req.body;

    // Validate required fields
    const requiredFields = [
      'title', 'description', 'startDate', 'endDate', 
      'maxParticipants', 'prizePool', 'registrationDeadline',
      'eventType', 'eligibility', 'theme'
    ];
    
    const missingFields = requiredFields.filter(field => !req.body[field]);
    if (missingFields.length > 0) {
       res.status(400).json({
        success: false,
        message: `Missing required fields: ${missingFields.join(', ')}`
      });
      return
    }

    // Validate event type
    if (!Object.values(Mode).includes(eventType)) {
       res.status(400).json({
        success: false,
        message: `Invalid event type. Must be one of: ${Object.values(Mode).join(', ')}`
      });
      return
    }

    // Validate dates
    const start = new Date(startDate);
    const end = new Date(endDate);
    const deadline = new Date(registrationDeadline);
    
    if (start >= end) {
       res.status(400).json({
        success: false,
        message: "End date must be after start date"
      });
      return
    }

    if (deadline >= start) {
       res.status(400).json({
        success: false,
        message: "Registration deadline must be before start date"
      });
      return
    }

    // Create the hackathon
    const newHackathon = await hackathon.create({
      title,
      description,
      startDate: start,
      endDate: end,
      maxParticipants: Number(maxParticipants),
      prizePool,
      registrationDeadline: deadline,
      eventType,
      venue,
      platform,
      platformLink,
      eligibility: {
        ageMin: Number(eligibility.ageMin),
        ageMax: Number(eligibility.ageMax),
        skillLevel: eligibility.skillLevel,
        location: eligibility.location,
        requirements: eligibility.requirements
      },
      theme,
      tracks: tracks.filter((t: string) => t?.trim() !== ''),
      rules: rules.filter((r: string) => r?.trim() !== ''),
      schedule: schedule.map((item: ScheduleItem) => ({
        date: item.date,
        time: item.time,
        event: item.event,
        description: item.description
      })),
      sponsors: sponsors.filter((s: string) => s?.trim() !== ''),
      contact,
      createdBy: userId
    });

    // Create judge records if any
    if (judges?.length > 0) {
      const validJudges = judges.filter((j: JudgeSubmission) => 
        j.name && j.email && j.expertise
      //@ts-ignore
      ).map(j => ({
        ...j,
        invited: j.invited || false
      }));

      if (validJudges.length > 0) {
        await judge.create({
          hackathonId: newHackathon._id,
          userId,
          judges: validJudges
        });
      }
    }

    // Handle admin privileges
    const existingAdmin = await Admin.findOne({ UserId: userId });
    let isNewAdmin = false;

    if (existingAdmin) {
      await Admin.updateOne(
        { UserId: userId },
        { $addToSet: { hackathonId: newHackathon._id } }
      );
    } else {
      await Admin.create({
        UserId: userId,
        hackathonId: [newHackathon._id],
      });
      await User.findByIdAndUpdate(userId, { role: "admin" });
      isNewAdmin = true;
    }

    // Successful response
    res.status(201).json({
      success: true,
      message: "Hackathon created successfully",
      data: {
        hackathon: newHackathon,
        isNewAdmin
      }
    });

  } catch (error: any) {
    console.error("Error creating hackathon:", error);

    // Handle duplicate title error
    if (error.code === 11000 && error.keyPattern?.title) {
      res.status(409).json({
        success: false,
        message: "A hackathon with this title already exists"
      });
      return 
    }

    // Handle validation errors
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map((err: any) => err.message);
       res.status(400).json({
        success: false,
        message: "Validation failed",
        errors
      });
      return
    }

    // Generic error handler
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message
    });
  }
});


app.put("/hackathon", verify, async (req: Request, res: Response): Promise<void> => {
  try {
    let user = (req as any).user.uid;
    let { HName, overview, tags, mode, location, timestamp, hackathonId } = req.body;
    let adminInfo = await Admin.findOne({
      UserId: user,
      hackathonId: { $in: [hackathonId] }
    });
    if (!adminInfo) {
       res.status(403).json({ msg: "Not authorized to edit this hackathon" });
       return
    }
    let updatedHackathon = await hackathon.updateOne(
      { _id: hackathonId },
      { $set: { HName, overview, tags, mode, location, timestamp } }
    );
    if (updatedHackathon.modifiedCount === 0) {
       res.status(400).json({ msg: "No changes were made" });
       return
    }
     res.status(200).json({ msg: "Hackathon updated successfully" });
     return
  } catch (error) {
    console.error("Error updating hackathon:", error);
     res.status(500).json({ msg: "Internal Server Error", error });
     return
  }
});
//---------------------------------------------------------------------------


interface TeamMember {
  name: string;
  email: string;
  role: string;
}

interface RegistrationData {
  fullName: string;
  email: string;
  phone: string;
  education: string;
  heardFrom: string;
  lookingForTeam: boolean;
  teamPreference: string;
  skills: string;
  hasTeam: boolean;
  teamName?: string;
  teamMembers?: TeamMember[];
}

app.post("/register/:hackathonId", verify, async (req: Request, res: Response): Promise<void> => {
  try {
    const hackathonId = req.params.hackathonId; // Get the hackathon ID from URL params
    const userId = (req as any).user;
    const data: RegistrationData = req.body;

    // Create or update user profile
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        name: data.fullName,
        email: data.email,
        phone: data.phone,
        education: data.education,
        role: "participant"
      },
      { new: true }
    );

    if (!updatedUser) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    // If user is looking for team
    if (data.lookingForTeam) {
      await Participant.findOneAndUpdate(
        { userId },
        {
          lookingForTeam: true,
          teamPreference: data.teamPreference
        },
        { upsert: true }
      );
    }

    // If user has a team
    if (data.hasTeam && data.teamName && data.teamMembers) {
      // Check if team name already exists
      const existingTeam = await Team.findOne({ teamName: data.teamName });
      if (existingTeam) {
        res.status(400).json({ error: "Team name already exists" });
        return;
      }

      // Create the team
      const team = await Team.create({
        captain: userId,
        teamName: data.teamName,
        participantId: [userId], // Start with the captain
      });

      // Process team members
      for (const member of data.teamMembers) {
        // Check if user exists
        let memberUser = await User.findOne({ email: member.email });
        
        if (!memberUser) {
          // Create placeholder account for the team member
          memberUser = await User.create({
            name: member.name,
            email: member.email,
            role: "participant",
          });
        }

        // Add member to team
        await Team.findByIdAndUpdate(
          team._id,
          {
            $addToSet: { participantId: memberUser._id }
          }
        );
      }
    }

    res.status(201).json({
      message: "Registration successful",
      user: updatedUser
    });

  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});



//--------------------------------------------------------------------------
app.put("/edit-team/:teamId", verify, async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
      let user = (req as any).user.uid; // Extract logged-in user ID
      let { teamName, email, hackathonId } = req.body;
      let { teamId } = req.params;

      // Validate input
      if (!teamId) {
          res.status(400).json({ error: "Team ID is required" });
          return;
      }

      if (!teamName && !email && !hackathonId) {
          res.status(400).json({ error: "Provide at least one field to update" });
          return;
      }

      // Find the team by ID
      let team = await Team.findById(teamId);
      if (!team) {
          res.status(404).json({ error: "Team not found" });
          return;
      }

      // Check if the logged-in user is the captain
      if (String(team.captain) !== user) {
          res.status(403).json({ error: "Only the team captain can edit the team" });
          return;
      }

      let updateFields: any = {};

      // Update team name if provided
      if (teamName) {
          updateFields.teamName = teamName;
      }

      // Update participant list if emails are provided
      if (email && Array.isArray(email)) {
          const users = await User.find({ email: { $in: email } }, "_id");
          const participantId = users.map(user => user._id);

          if (participantId.length !== email.length) {
              res.status(400).json({ error: "Some emails do not exist in the system" });
              return;
          }

          updateFields.participantId = participantId;
      }

      // Update hackathon participation if provided
      if (hackathonId) {
          updateFields.hackathonParticipatedId = {
              $addToSet: { hackathonParticipatedId: hackathonId } // Ensures no duplicates
          };
      }

      // Apply the update
      let updatedTeam = await Team.findByIdAndUpdate(teamId, updateFields, { new: true });

      res.status(200).json({
          message: "Team details updated successfully!",
          team: updatedTeam
      });

  } catch (error: any) {
      next(error); // Use Express error handler
  }
})


app.post("/project", verify, async (req, res) : Promise<void> => {
  try {
    let user = (req as any).user.uid;
    let { hackathonParticipatedId, overview, techstack, linkOfPPT } = req.body;
    let team = await Team.findOne({
      captain: user,
      hackathonParticipatedId: { $in: [hackathonParticipatedId] }
    });

    if (!team) {
       res.status(400).json({ msg: "Team doesn't exist or is not registered for this hackathon" });
       return
    }
    await project.create({
      overview,
      techstack,
      linkOfPPT,
      teamId: team._id,
      hackathonId: hackathonParticipatedId
    });
     res.status(200).json({ msg: "done" });
     return
  } catch (error) {
    console.error("Error creating project:", error);
     res.status(500).json({ msg: "Internal Server Error" });
     return
  }
});

app.post("/score", async (req, res) : Promise<void> => {
  try {
    let { score, hackathon, teamId } = req.body;
    let user = (req as any).user.uid;
    let judgeExists = await judge.findOne({
      _id: user,
      hackathonId: { $in: [hackathon] }
    });
    if (!judgeExists) {
       res.status(403).json({ msg: "Unauthorized: You are not a judge for this hackathon" });
       return
    }
    let updateScore = await project.updateOne(
      { teamId: teamId }, 
      { $set: { score: score } }
    );
    if (updateScore.modifiedCount === 0) {
       res.status(400).json({ msg: "Failed to update score. Project not found." });
       return
    }
     res.status(200).json({ msg: "Score updated successfully" });
     return
  } catch (error) {
    console.error("Error updating score:", error);
     res.status(500).json({ msg: "Internal Server Error" });
     return
  }
});


app.listen(8080, () => {
  console.log("Started")
});
